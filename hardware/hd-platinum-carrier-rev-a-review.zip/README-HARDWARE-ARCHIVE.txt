HD Platinum carrier Rev A - engineering first article

Start with hardware/README.md. Native KiCad source, manufacturing files,
validation reports, source references and tools are included. Links into
the software repository require the full repository checkout; this archive
contains hardware only. Physical fit, RF behavior and deployable ESP32
firmware remain qualification work. No production release is implied.
